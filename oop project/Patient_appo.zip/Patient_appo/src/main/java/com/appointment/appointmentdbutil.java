package com.appointment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class appointmentdbutil {
	
	private static ResultSet rs=null;

public static boolean insertappointment(String Patient_name,String Age,String NIC,String Guardian_name,String Address,String Telephone_no,String Doctor_name,String Date ) {

	boolean IsSuccess=false;
	
	
//create database connection	
	
	String url="jdbc:mysql://localhost:3306/appointment";
	String user="root";
	String pass="MYONE12#@5s";
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,user,pass);
	    Statement stmt= con.createStatement();
		String sql="insert into appointment values(0,'"+ Patient_name+"','"+Age+"','"+NIC+"','"+Guardian_name+"','"+Address+"','"+Telephone_no+"','"+Doctor_name+"','"+ Date+"')";
	  
		
		
	int rs=stmt.executeUpdate(sql);
	  if(rs>0) {
		  IsSuccess=true;
		 
	  }
	  else {
		  IsSuccess=false;
	  }
	
	
	
	}
	
	
	catch (Exception e){
		e.printStackTrace();
	}
	return IsSuccess;
	
	
	
	
}

}
	
	
	
	
	
	

